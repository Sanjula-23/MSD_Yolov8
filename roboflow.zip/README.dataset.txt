# Cube,Sphere,Cylinder > 2025-05-03 8:58am
https://universe.roboflow.com/object-detection-bc5cf/cube-sphere-cylinder

Provided by a Roboflow user
License: CC BY 4.0

